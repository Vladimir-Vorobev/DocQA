from striprtf.striprtf import rtf_to_text
import docx2txt
import subprocess

class DocConverter:
    def convert_doc(filepath, filepath_to_save):
        if filepath.endswith('.docx'):
            text = docx2txt.process(filepath)
            with open(filepath_to_save.replace('.docx', '.txt'), "w") as output:
                output.write(text)
            return filepath_to_save.replace('.docx', '.txt')

        elif filepath.endswith('.doc'):
            text = subprocess.check_output(["antiword", filepath]).decode("utf-8")
            with open(filepath_to_save.replace('.doc', '.txt'), "w") as output:
                output.write(text)
            return filepath_to_save.replace('.doc', '.txt')
        elif filepath.endswith('.rtf'):
            with open(filepath_to_save.replace('.rtf', '.txt'), "w") as output:
                output.write(rtf_to_text(open(filepath, 'r').read()))
            return filepath_to_save.replace('.rtf', '.txt')
        elif filepath.endswith('.txt'):
            with open(filepath_to_save, "w") as output:
                output.write(open(filepath, 'r').read())
            return filepath_to_save